package com.example.touristapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.example.touristapp.R;
import com.example.touristapp.dao.AttractionsDao;
import com.example.touristapp.dao.FavouriteDao;
import com.example.touristapp.database.AppDb;
import com.example.touristapp.entities.Attractions;
import com.example.touristapp.entities.Favourite;

public class AttractionDetailScreen extends AppCompatActivity {
    Toast t;
    AppDb db = null;
    AttractionsDao attractionsDAO = null;
    FavouriteDao favouriteDao=null;
    Attractions details=null;
    TextView tvName,tvDesc,tvPhone,tvWebsite;
    ImageView tvImage;
    RatingBar tvRatings;
    double ratings;
    SharedPreferences preferences;
    String name,user;
    Favourite f=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attraction_detail_screen);
        //set the database
        db = AppDb.getInstance(getApplicationContext());
        attractionsDAO = db.attractionDao();
        favouriteDao=db.favoritesDao();
        // get the id from the intent
        Intent i = getIntent();
        name = i.getStringExtra("attractionName");
        if (name.isEmpty()) {
            Log.d("TAG", "Error getting attraction name from the intent");
            return;
        }
        Log.d("MESSAGE"," the User Name is"+user);
        // get the item from the database
        Attractions details=attractionsDAO.getByName(name);
        if (details == null) {
            Log.d("TAG", "Sorry, this product does not exist.");
            return;
        }

        // update the UI based on the item
        tvName = findViewById(R.id.tvName);
        tvImage=findViewById(R.id.tvPhoto);
        tvDesc = findViewById(R.id.tvDetail);
        tvPhone = findViewById(R.id.tvPhone);
        tvWebsite=findViewById(R.id.tvWebsite);
        tvRatings=findViewById(R.id.ratingBar);
        //set the details to UI
        tvName.setText(details.name);
        tvDesc.setText(details.description);
        tvPhone.setText(details.phone_no);
        tvWebsite.setText(details.website);
        tvRatings.setRating((float) details.ratings);
        Context c=getApplicationContext();
        int id=c.getResources().getIdentifier("drawable/" + details.image, null, c.getPackageName());
        ToggleButton toggle=(ToggleButton)findViewById(R.id.favBtndetail);
        tvImage.setImageResource(id);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Intent j = getIntent();
                user = j.getStringExtra("userName");
                if (isChecked) {
                    Log.d("ABC", "Checked");
                    if(user==null){
                        SharedPreferences sharedPrefs = getSharedPreferences("checkbox", Context.MODE_PRIVATE);
                        user = sharedPrefs.getString("username", "");

                    }
                    else {
                        Favourite newFavourite = new Favourite(user, name);
                        favouriteDao.insert(newFavourite);
                    }
                } else {
                    // The toggle is disabled
                    Favourite f = favouriteDao.getFavouriteByAttraction(user, name);
                    if (f == null) {
                        Log.d("ABC","no-object");
                    }
                    else{
                        favouriteDao.deleteFavouriseByUser(user, name);
                    }
                }

            }});

        // onclick listener for rating bar
        tvRatings.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar arg0, float rateValue, boolean arg2) {
                // TODO Auto-generated method stub
                Log.d("Rating", "rating is :"+rateValue);
                attractionsDAO.updateRatings(rateValue,details.name);
            }
        });


    }

    public void openDial(View view) {
        // 1. grab the phone number from tthe databse
        String number = tvPhone.getText().toString();
        Uri phoneNumber = Uri.parse("tel:"+number );

        // 2. Create an INTENT that says: "We want to make a phone call"
        Intent callIntent = new Intent(Intent.ACTION_DIAL);

        // 3. specify which number we want to call
        callIntent.setData(phoneNumber);

        // 4. Ask Android to figure out which application should make the phone call
        // 4a. Assuming that Android can find an appropriate application, start the intent
        if (callIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(callIntent);
        }
    }
    public void redirectToWebsite(View View){
        // 1. get the url from the textView(the website they want to visit)
        String address = tvWebsite.getText().toString();

        // 2. create an intent with the ACTION_VIEW (lets android know that you INTEND to visit a website)
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(address));

        // 3. Let android search for an appropriate app to open the website
        // 3a. If we can find it, great, open it!
        if (browserIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(browserIntent);
        }

    }
    //when go back button pressed
    public void goBackBtnPressed(View view){
        finish();
    }
    //when Logout button pressed
    public void logoutBtnPressed(View view){
        preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putBoolean("checked",false);
        editor.apply();
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}