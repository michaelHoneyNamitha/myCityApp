package com.example.touristapp.adapters;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.touristapp.R;
import com.example.touristapp.entities.Attractions;

import java.util.ArrayList;

public class AttractionListAdapter extends ArrayAdapter<Attractions> {


    public AttractionListAdapter(Context context, ArrayList<Attractions> places)
    {
        super(context, 0, places);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Attractions site = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.custom_row_layout, parent, false);
        }

        TextView tvName
                = (TextView) convertView.findViewById(R.id.tvName);
        TextView tvHome
                = (TextView) convertView.findViewById(R.id.tvAdress);
        ImageView tvImage
                = (ImageView) convertView.findViewById(R.id.tvImage);

      // ToggleButton favButton=(ToggleButton)convertView.findViewById(R.id.favBtn);

        // Populate the data into the template view using the data object
        tvName.setText(site.name);
        tvHome.setText(site.address);
        Context c=getContext();
        int id=c.getResources().getIdentifier("drawable/" + site.image, null, c.getPackageName());
        tvImage.setImageResource(id);
       /* favButton.setOnCheckedChangeListener( new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton toggleButton, boolean isChecked)
            {
                if(isChecked)
                {
                    Log.d("MSG","True") ;
                }
                else
                {
                    Log.d("MSG","False") ;
                }

            }
        });*/

        return convertView;

    }



}

