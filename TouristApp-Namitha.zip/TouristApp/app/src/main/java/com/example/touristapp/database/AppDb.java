package com.example.touristapp.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.touristapp.dao.AttractionsDao;
import com.example.touristapp.dao.FavouriteDao;
import com.example.touristapp.dao.UserDao;
import com.example.touristapp.entities.Attractions;
import com.example.touristapp.entities.Favourite;
import com.example.touristapp.entities.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {User.class, Attractions.class, Favourite.class}, version = 1, exportSchema = false)
public abstract class AppDb extends RoomDatabase {
    private static AppDb INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    public abstract UserDao dataDao();
    public abstract AttractionsDao attractionDao();
    public abstract FavouriteDao favoritesDao();

    public synchronized static AppDb getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = buildDatabase(context);
        }
        return INSTANCE;
    }

    private static AppDb buildDatabase(final Context context) {
        return Room.databaseBuilder(context,
                AppDb.class,
                "MyCity-db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .addCallback(new Callback() {
                    @Override
                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
                        super.onCreate(db);
                        Executors.newSingleThreadScheduledExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                getInstance(context).dataDao().insertAll(User.populateData());
                                getInstance(context).attractionDao().insertAll(Attractions.populateAttractions());
                                getInstance(context).favoritesDao().insertAll(Favourite.populateFavourite());
                            }
                        });
                    }
                })
                .build();
    }

}
