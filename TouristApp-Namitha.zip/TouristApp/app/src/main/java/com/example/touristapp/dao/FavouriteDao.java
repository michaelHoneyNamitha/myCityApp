package com.example.touristapp.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.touristapp.entities.Attractions;
import com.example.touristapp.entities.Favourite;

import java.util.List;

@Dao
public interface FavouriteDao {
    @Insert
    void insertAll(Favourite...favourites);

    @Query("SELECT attraction_name FROM favourites where username=:username")
    public List<String> getAllfavourites(String username) ;


    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insert(Favourite f);

    @Query("SELECT * FROM favourites WHERE username=:username and attraction_name=:attractionname")
    public Favourite getFavouriteByAttraction(String username,String attractionname) ;

    @Query("DELETE FROM favourites WHERE username = :username and attraction_name=:attractionname")
    public void deleteFavouriseByUser(String username,String attractionname);

    @Query("DELETE FROM favourites WHERE username = :username ")
    public void deleteFavourite(String username);



}
