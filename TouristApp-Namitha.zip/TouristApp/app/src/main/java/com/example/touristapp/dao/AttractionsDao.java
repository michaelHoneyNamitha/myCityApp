package com.example.touristapp.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.touristapp.entities.Attractions;

import java.util.List;

@Dao
public interface AttractionsDao {
    //database queries go here

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Attractions attractions);

    @Query("SELECT * FROM attractions")
    List<Attractions> getAllAttractions() ;
    @Insert
    void insertAll(Attractions...attractions);

    @Query("SELECT * FROM attractions WHERE name=:attractionName")
    public Attractions getByName(String attractionName) ;

    //updating the ratings when the user provide the ratings for a specific attractions
    @Query("UPDATE attractions SET ratings=:customerRating WHERE name=:attaractionName")
    public  void  updateRatings(double customerRating,String attaractionName);

}
