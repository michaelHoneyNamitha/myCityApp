package com.example.touristapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Insert;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.ToggleButton;

import com.example.touristapp.R;
import com.example.touristapp.adapters.AttractionListAdapter;
import com.example.touristapp.dao.AttractionsDao;
import com.example.touristapp.dao.FavouriteDao;
import com.example.touristapp.database.AppDb;
import com.example.touristapp.entities.Attractions;

import java.util.ArrayList;

public class AttractionListActivity extends AppCompatActivity {

    AppDb db = null;
    AttractionsDao attractionsDAO = null;
    FavouriteDao favouriteDAO=null;
    ArrayList<Attractions> attractionList=new ArrayList<>();;
    ListView lvAttractions;
    String user;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attraction_list);
        db =AppDb.getInstance(getApplicationContext());
        attractionsDAO = db.attractionDao();
        this.favouriteDAO=db.favoritesDao();
        //get the user send from LoginScreen when this screen loads
        Intent intent = getIntent();
        user = intent.getStringExtra("userName");
        // use the productDAO to get all the database
        ArrayList<Attractions> attractionList = (ArrayList<Attractions>) attractionsDAO.getAllAttractions();
        AttractionListAdapter siteAdapter = new AttractionListAdapter(this, attractionList);

       lvAttractions = findViewById(R.id.lv);
       lvAttractions.setAdapter(siteAdapter);

       lvAttractions.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("ABC","item cilicked: "+i);
                Log.d("button","button clicked"+i);
                // send the id of the clicked product to Screen #3
                Attractions a = attractionList.get(i);
                String name=a.name;
                Intent intent = new Intent(getApplicationContext(), AttractionDetailScreen.class);
                intent.putExtra("attractionName",name);
                intent.putExtra("userName",user);
                startActivity(intent);
            }
        });

    }
    //when togglebuttonpressed
   /* public void favouriteButtonClicked(View view){
        //save the favourite to database
        ToggleButton favButton=findViewById(R.id.favBtn);
        favButton.setOnCheckedChangeListener( new CompoundButton.OnCheckedChangeListener()

    }*/
    //when go back button pressed
    public void goBackBtnPressed(View view){
        finish();
    }
    //when Logout button pressed
    public void logoutBtnPressed(View view){
        preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putBoolean("checked",false);
        editor.apply();
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}