package com.example.touristapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.touristapp.R;
import com.example.touristapp.dao.AttractionsDao;
import com.example.touristapp.dao.FavouriteDao;
import com.example.touristapp.database.AppDb;

import java.util.List;

public class HomeScreenActivity extends AppCompatActivity {
    AppDb db = null;
    AttractionsDao attractionsDAO = null;
    FavouriteDao favouriteDAO=null;
    String user=null;
    SharedPreferences preferences;
    LinearLayout favouriteMsg;
    List<String> fList;
   SharedPreferences sharedPrefs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        //set the database
        this.db =AppDb.getInstance(getApplicationContext());
        this.attractionsDAO = this.db.attractionDao();
        this.favouriteDAO=this.db.favoritesDao();
        //get the user send from LoginScreen when this screen loads
        Intent intent = getIntent();
        user = intent.getStringExtra("userName");
        favouriteMsg = (LinearLayout) findViewById(R.id.resultsSection);
        //  TextView fname=findViewById(R.id.textFavoutite);
        fList = this.favouriteDAO.getAllfavourites(user);
        if(fList.size()==0){
            favouriteMsg.setVisibility(View.INVISIBLE);
        }
        else {
            user = intent.getStringExtra("userName");
            favouriteMsg.setVisibility(View.VISIBLE);
            //  fname.setText("Your Favourites");
            ListView lv = findViewById(R.id.lisview);
            ArrayAdapter<String> fAdapter
                    = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fList);
            lv.setAdapter(fAdapter);

        }


    }
    public void showAttractionClicked(View v) {
        Intent intent = getIntent();
        user = intent.getStringExtra("userName");

        Log.d("ABC","Testing");
        Log.d("ABC",user);
        Intent i = new Intent(this, AttractionListActivity.class);
        i.putExtra("userName", user);
        startActivity(i);
    }
    public void ClearFavourites(View view){
        this.favouriteDAO.deleteFavourite(user);
        fList.clear();
        favouriteMsg.setVisibility(View.INVISIBLE);

    }


    //when Logout button pressed
    public void logoutBtnPressed(View view) {
        preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("checked", false);
        editor.apply();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}