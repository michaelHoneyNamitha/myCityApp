package com.example.touristapp.entities;

import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.example.touristapp.R;

@Entity(tableName = "attractions")
public class Attractions {
    //columns
    @PrimaryKey(autoGenerate = true)
    @NonNull
    public int id;
    public String name;
    public String address;
    public String image;
    public String phone_no;
    public String website;
    public String description;
    public double price;
    public double ratings;

    //constructors
    public Attractions( String name, String address, String image,String phone_no, String website,String description, double price,double ratings) {

        this.name = name;
        this.address = address;
        this.image = image;
        this.phone_no = phone_no;
        this.website = website;
        this.description=description;
        this.price = price;
        this.ratings=ratings;
    }
    @Ignore
    public Attractions(String name, String address, String image) {
        this.name = name;
        this.address = address;
        this.image = image;

    }
    //getters And Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getRatings() {
        return ratings;
    }

    public void setRatings(double ratings) {
        this.ratings = ratings;
    }

    @Override
    public String toString() {
        return "Attractions{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", Address='" + address + '\'' +
                ", image=" + image +
                ", phone_no='" + phone_no + '\'' +
                ", website=" + website +
                ", price=" + price +
                ", ratings=" + ratings +
                '}';
    }
    //populate the databsase with the Attractions
    public static Attractions[] populateAttractions() {
        return new Attractions[] {
                new Attractions("Kanyakumari","KanyaKumari,TN,India", "kanyakumari_sunrise","+91 9769495866","https://kanniyakumari.nic.in/tourist-information/","Kanyakumari is the southernmost point of peninsular India and the meeting point of three oceans-the Bay of Bengal, the Arabian Sea and the Indian Ocean. Besides its importance as a Hindu pilgrim center, it is famous for its beautiful views of sunrise and sunset over the waters.",100.00,4.0),
                new Attractions("Hogenakkal Falls","Hogenakkal,TN,India","hogenakkal_falls","+91 9943331736","http://www.tamilnadutourism.org/hotels/Hogenakkal.aspx","There are many scintillating waterfalls in India that are considered to hold resemblance with the famous Niagara Falls of the West",160.00,4.3),
                new Attractions("Alappey","Alappey,KL,India","boathouse","+91 9961466878","https://www.keralahouseboat.in/","Known as the 'City of Canals' and the 'Venice of the East', Alleppey is the centre of backwater houseboat tourism. Nearby Kumarakom is also a popular place for houseboats. ",170.00,4.9),
                new Attractions("Mahabalipuram","Mahabalipuram,TN,India","gate_of_mahabalipuram","+91 7650466789","http://www.tamilnadutourism.org/mahabalipuram.html","Mahabalipuram is one of the oldest cities in India. Present day, it is known for its great monuments, cave sanctuaries and sculptures.Mahabalipuram is famous for its vast beach, monoliths, stone carvings and temples.",90.00,4.0),
                new Attractions("Vagamon","Vagamon,KL,India","vagamon_kerala","+91 8760789543","https://www.vagamon.com/","Vagamon hill station is comprised of a beautiful series of hillocks, valleys and cascading waterfalls that make it the ideal getaway for tourists. Take a walk along the narrow, mist covered zigzag roads that wind up the hills and experience true bliss. For adventure seekers, there is an option of trekking, para gliding or rock climbing.",180.00,4.7)

        };
    }
}
