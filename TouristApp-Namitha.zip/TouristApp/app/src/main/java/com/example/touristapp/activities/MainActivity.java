package com.example.touristapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.touristapp.R;
import com.example.touristapp.dao.UserDao;
import com.example.touristapp.database.AppDb;
import com.example.touristapp.entities.User;

import java.util.List;
//group2- namitha& neena
public class MainActivity extends AppCompatActivity {
    // database and dao variable
    AppDb db = null;
    UserDao userDAO = null;
    User users;
    Toast t;
    EditText etUser,etPassword;
    String user,password;
    CheckBox rememberUser;
    SharedPreferences preferences;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.db =AppDb.getInstance(getApplicationContext());
        this.userDAO = this.db.dataDao();
        rememberUser=findViewById(R.id.checkBox);

        //to check whether remember Me is checked or not
        preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
        boolean b=preferences.getBoolean("checked",false);
        String rememberuser=preferences.getString("userName","");
        String password=preferences.getString("password","");
        if(b==true) {
            intent = new Intent(this, HomeScreenActivity.class);
            intent.putExtra("userName",rememberuser);
            startActivity(intent);
        }
    }
    public void loginButtonPressed(View view){
        // get userName and password from UI
        etUser=findViewById(R.id.etUserName);
        etPassword=findViewById(R.id.etPassword);
        user=etUser.getText().toString();
        password=etPassword.getText().toString();

        //get the user information from the database
        User u = userDAO.getUsersById(user,password);
        
        if (u==null) {
            //check whether the username in the database
            String uname=userDAO.getUsersByName(user);
            if(uname==null){
                //username does not exist
                String msg = "The username does not exist.";
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            }
            else {
                // the person is not in the database
                String msg = "The username/password combination is incorrect.";
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            }
            return;
        }
        else {
            // it goes to screen #2 IF the person types in valide user name and password

            Log.d("ABC","Testing");
            Log.d("ABC",user);
            Intent i=new Intent(this,HomeScreenActivity.class);
            i.putExtra("userName",user);
            startActivity(i);
        }


    }
    public void rememberMeChecked(View v){
        etUser=findViewById(R.id.etUserName);
        user=etUser.getText().toString();
        preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        if(rememberUser.isChecked()){
            editor.putBoolean("checked",true);
            editor.putString("userName",user);
            editor.putString("password",password);
            editor.apply();
        }
        else{
            editor.putBoolean("checked",false);
            editor.apply();

        }
    }

}