package com.example.touristapp.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.touristapp.entities.User;

import java.util.List;
@Dao
public interface UserDao {
    // INSERT  (Insert a new Employee)
    // When Room sees the @Insert annotation,
    // it will know to use the insert(...) function
    // to add things to the database
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insert(User user);

    @Query("SELECT * FROM user")
    public List<User> getAllUsers() ;
    @Insert
    void insertAll(User... users);

    @Query("SELECT username  FROM user WHERE username= :user")
    public String getUsersByName(String user);
    @Query("SELECT *  FROM user WHERE username= :user and password= :pass")
    public User getUsersById(String user,String pass);
}
