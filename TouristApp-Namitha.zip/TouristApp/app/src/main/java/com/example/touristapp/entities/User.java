package com.example.touristapp.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    //columns userName and password
    @PrimaryKey
    @NonNull
    public String username;
    public String password;

    //constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
    //geter and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    //populate the databsase with this users
    public static User[] populateData() {
        return new User[] {
                new User("thanos", "5555"),
                new User("wonderwoman", "abcd")
        };
    }
}

