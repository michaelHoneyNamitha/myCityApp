package com.example.touristapp.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "favourites")
public class Favourite {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    public int id;
    public String username;
    public String attraction_name;

    //constructor
    public Favourite(String username, String attraction_name) {
        this.id = id;
        this.username = username;
        this.attraction_name = attraction_name;
    }

    //getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAttraction_name() {
        return attraction_name;
    }

    public void setAttraction_name(String attraction_name) {
        this.attraction_name = attraction_name;
    }

    @Override
    public String toString() {
        return "Favourite{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", attraction_name='" + attraction_name + '\'' +
                '}';
    }
    public static Favourite[] populateFavourite() {
        return new Favourite[]{
                new Favourite("thanos", "Kanyakumari"),
                new Favourite("thanos", "Mahabalipuram"),
                new Favourite("wonderwoman", "Hogenakkal Falls")
        };
    }
}